package model;

public class ModelException extends Exception {
	
	public ModelException(String msgDeErro) {
		super(msgDeErro);
	}

}
